package solution;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class Userinterface {
	Stage theStage;
	/**********************************************************************************************
	 * 
	 * Attributes
	 * 
	 **********************************************************************************************/

	/*
	 * Constants used to parameterize the graphical user interface. We do not use a
	 * layout manager for this application. Rather we manually control the location
	 * of each graphical element for exact control of the look and feel.
	 */
	private final double BUTTON_WIDTH = 60;
	private final double BUTTON_OFFSET = BUTTON_WIDTH / 2;

	// These are the application values required by the user interface
	private Label label_Doublemainline = new Label("Mentor Function");

	
	
	private Button ind_score = new Button(" Submit Data");
	private Button student = new Button(" Student Details");
	
	TextField DataSource1 = new TextField();
	TextField DataSource2 = new TextField();

	private double buttonSpace;

	public Userinterface(Pane theRoot, Stage Stage) {

		// There are five gaps. Compute the button space accordingly.
		buttonSpace = mainline.WINDOW_WIDTH / 5;

		// Label theScene with the name of the mainline, centered at the top of the pane
		setupLabelUI(label_Doublemainline, "Arial", 24, mainline.WINDOW_WIDTH, Pos.CENTER, 0, 10);

		// Button UI
		setupButtonUI(ind_score, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.3 * buttonSpace - BUTTON_OFFSET,
				300);
		
		setupButtonUI(student, "Symbol", 16, BUTTON_WIDTH, Pos.BASELINE_CENTER, 2.6 * buttonSpace - BUTTON_OFFSET+ 150,
				100);

		DataSource1.setLayoutX(300);
		DataSource1.setLayoutY(200);	
;		DataSource2.setLayoutX(300);
		DataSource2.setLayoutY(100);

		
		student.setOnAction((event) -> {
		try {
			exceltomysql();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		}
	);

		// Place all of the just-initialized GUI elements into the pane
		theRoot.getChildren().addAll(label_Doublemainline, ind_score,DataSource1,DataSource2,student);

	}
	
	

	
	private void exceltomysql() throws SQLException, ClassNotFoundException, NullPointerException{
		String b= null;
		FileChooser FChooser = new FileChooser(); // this is the code for selecting the excel file by clicking on the
		// browse button)

File selectedFile = FChooser.showOpenDialog(theStage); // This code will only select the file with .xlsx format

String fileName = selectedFile.getName().toString();
if (fileName.toLowerCase().endsWith(".xls") && !fileName.toLowerCase().startsWith("~$")) {
b= selectedFile.getAbsolutePath();
} else {
b= null;

}
		


try{
    Class.forName("com.mysql.jdbc.Driver");
    Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/","root","nikhil");
    con.setAutoCommit(false);
    PreparedStatement pstm = null ;
    PreparedStatement pstm1 = null ;
    PreparedStatement pstm2 = null ;
    PreparedStatement pstm3 = null ;
    PreparedStatement pstm6 = null ;

    FileInputStream input = new FileInputStream(b);
    POIFSFileSystem fs = new POIFSFileSystem( input );
    @SuppressWarnings("resource")
HSSFWorkbook wb = new HSSFWorkbook(fs);
    HSSFSheet sheet = wb.getSheetAt(0);
    Row row;
    try {
    String sql6 = "create database yuu";
    pstm6 = (PreparedStatement) con.prepareStatement(sql6);
    
    pstm6.execute();}
    catch(Exception e) {
    	System.out.println("already present");
    }
    String sql3 = "Use yuu";




         String sql1 = "Create table student1(rollno int, name Varchar(100), deptno int, address Varchar(100))";
         pstm3 = (PreparedStatement) con.prepareStatement(sql3);
      //   pstm = (PreparedStatement) con.prepareStatement(sql);
         pstm1 = (PreparedStatement) con.prepareStatement(sql1);
         try {
         pstm3.execute();}
         catch(Exception e) {
         	System.out.println("already present");
         }
      //  pstm.execute();
         try {
        pstm1.execute();
         } catch(Exception e) {
         	System.out.println("already present");
         }
    
   
    for(int i=1; i<=sheet.getLastRowNum(); i++){
        row = sheet.getRow(i);
        int rollno = (int) row.getCell(0).getNumericCellValue();
        String name = row.getCell(1).getStringCellValue();
        int deptno = (int) row.getCell(2).getNumericCellValue();
        String address = row.getCell(3).getStringCellValue();
        
        
    
        String sql2 = "INSERT INTO student1 VALUES('"+rollno+"','"+name+"','"+deptno+"','"+address+"')";

        pstm2 = (PreparedStatement) con.prepareStatement(sql2);

    

        pstm2.execute();
        System.out.println("Import rows "+i);
    }
    con.commit();
    pstm1.close();

    pstm2.close();
    pstm3.close();
    pstm6.close();

    con.close();
    input.close();
    System.out.println("Success import excel to mysql table");
}catch(ClassNotFoundException e){
    System.out.println(e);
}catch(SQLException ex){
    System.out.println(ex);
}catch(IOException ioe){
    System.out.println(ioe);
}

}






	private void setupTextUI(TextField t, String ff, double f, double w, Pos p, double x, double y, boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}

	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

	/**********************************************************************************************
	 * 
	 * User Interface Actions
	 * 
	 **********************************************************************************************/

	
}